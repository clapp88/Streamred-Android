import 'dart:async';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:video_player/video_player.dart';
import 'package:chewie/chewie.dart';
import '../services/api_service.dart';

class StreamScreen extends StatefulWidget {
  final String nanoId;
  final Map<String, dynamic> data;
  const StreamScreen({super.key, required this.nanoId, required this.data});

  @override
  State<StreamScreen> createState() => _StreamScreenState();
}

class _StreamScreenState extends State<StreamScreen> {
  VideoPlayerController? controller;
  ChewieController? chewie;
  List chat = [];
  final chatCtrl = TextEditingController();
  bool loadingChat = true;
  Timer? chatTimer;

  @override
  void initState() {
    super.initState();
    final url = widget.data['hlsUrl'] ?? widget.data['videoUrl'] ?? widget.data['url'];
    if (url != null && url.toString().isNotEmpty) {
      controller = VideoPlayerController.networkUrl(Uri.parse(url.toString()));
      chewie = ChewieController(videoPlayerController: controller!, autoPlay: true, aspectRatio: 16 / 9);
    }
    loadChat();
    // Refresh chat every 2 seconds
    chatTimer = Timer.periodic(const Duration(seconds: 2), (_) => loadChat(silent: true));
  }

  Future<void> loadChat({bool silent = false}) async {
    if (!mounted) return;
    final messages = await context.read<ApiService>().getChat(widget.nanoId);
    if (mounted) {
      setState(() {
        chat = messages;
        if (!silent) loadingChat = false;
      });
    }
  }

  Future<void> send() async {
    final text = chatCtrl.text.trim();
    if (text.isEmpty) return;
    final ok = await context.read<ApiService>().sendChat(widget.nanoId, text);
    if (ok) {
      chatCtrl.clear();
      await loadChat();
    }
  }

  void showDonate() {
    showModalBottomSheet(
      context: context,
      builder: (ctx) => Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Text('Donate', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
            const SizedBox(height: 16),
            const Text('Donation support coming soon.\nThis will connect to the site’s donation system.'),
            const SizedBox(height: 24),
            ElevatedButton(onPressed: () => Navigator.pop(ctx), child: const Text('Close')),
          ],
        ),
      ),
    );
  }

  @override
  void dispose() {
    chatTimer?.cancel();
    controller?.dispose();
    chewie?.dispose();
    chatCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final api = context.watch<ApiService>();
    final channel = widget.data['channelName'] ?? widget.data['username'] ?? '';
    final following = api.isFollowing(channel);

    return Scaffold(
      appBar: AppBar(title: Text(widget.data['title'] ?? 'Watch')),
      body: Column(
        children: [
          if (chewie != null)
            AspectRatio(aspectRatio: 16 / 9, child: Chewie(controller: chewie!))
          else
            Container(height: 200, color: Colors.black, alignment: Alignment.center, child: const Text('Offline or no URL')),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
            child: Row(
              children: [
                Expanded(child: Text(channel, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w500))),
                OutlinedButton(
                  onPressed: () => api.toggleFollow(channel),
                  child: Text(following ? 'Following' : 'Follow'),
                ),
                const SizedBox(width: 8),
                ElevatedButton.icon(onPressed: showDonate, icon: const Icon(Icons.favorite, size: 16), label: const Text('Donate')),
              ],
            ),
          ),
          const Divider(height: 1),
          Expanded(
            child: loadingChat
                ? const Center(child: CircularProgressIndicator())
                : ListView.builder(
                    reverse: true,
                    itemCount: chat.length,
                    itemBuilder: (_, i) {
                      final m = chat[chat.length - 1 - i];
                      return ListTile(
                        dense: true,
                        title: Text(m['username'] ?? m['user']?['username'] ?? 'User', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13)),
                        subtitle: Text(m['message'] ?? m['content'] ?? ''),
                      );
                    },
                  ),
          ),
          Padding(
            padding: const EdgeInsets.all(8),
            child: Row(
              children: [
                Expanded(child: TextField(controller: chatCtrl, decoration: const InputDecoration(hintText: 'Send a message...', border: OutlineInputBorder(), isDense: true))),
                IconButton(icon: const Icon(Icons.send), onPressed: send),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
