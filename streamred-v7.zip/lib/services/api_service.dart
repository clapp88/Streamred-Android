import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

class ApiService extends ChangeNotifier {
  static const String baseUrl = 'https://88streams.st';
  String? _token;
  Map<String, dynamic>? user;
  final Set<String> followed = {};

  bool get isLoggedIn => _token != null;

  Future<void> loadToken() async {
    final prefs = await SharedPreferences.getInstance();
    _token = prefs.getString('auth_token');
    final saved = prefs.getStringList('followed') ?? [];
    followed.addAll(saved);
    if (_token != null) await fetchMe();
    notifyListeners();
  }

  Future<void> saveToken(String token) async {
    _token = token;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('auth_token', token);
    await fetchMe();
    notifyListeners();
  }

  Future<void> logout() async {
    _token = null;
    user = null;
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove('auth_token');
    notifyListeners();
  }

  Future<void> toggleFollow(String channel) async {
    if (followed.contains(channel)) {
      followed.remove(channel);
    } else {
      followed.add(channel);
    }
    final prefs = await SharedPreferences.getInstance();
    await prefs.setStringList('followed', followed.toList());
    notifyListeners();
  }

  bool isFollowing(String channel) => followed.contains(channel);

  Map<String, String> get headers => {
        'Content-Type': 'application/json',
        if (_token != null) 'Authorization': 'Bearer $_token',
      };

  Future<bool> login(String username, String password) async {
    try {
      final res = await http.post(
        Uri.parse('$baseUrl/api/auth/login'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'username': username, 'password': password}),
      );
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        final token = data['token'] ?? data['access_token'] ?? data['jwt'];
        if (token != null) {
          await saveToken(token.toString());
          return true;
        }
      }
    } catch (_) {}
    return false;
  }

  Future<void> fetchMe() async {
    if (_token == null) return;
    try {
      final res = await http.get(Uri.parse('$baseUrl/api/auth/me'), headers: headers);
      if (res.statusCode == 200) {
        user = jsonDecode(res.body);
        notifyListeners();
      }
    } catch (_) {}
  }

  Future<List> getStreams({int limit = 40}) async {
    try {
      final res = await http.get(Uri.parse('$baseUrl/api/streams?limit=$limit'), headers: headers);
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        return data is List ? data : (data['data'] ?? []);
      }
    } catch (_) {}
    return [];
  }

  Future<List> getVideos({int limit = 40}) async {
    try {
      final res = await http.get(Uri.parse('$baseUrl/api/videos?limit=$limit'), headers: headers);
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        return data is List ? data : (data['data'] ?? []);
      }
    } catch (_) {}
    return [];
  }

  Future<Map> search(String query) async {
    try {
      final res = await http.get(
        Uri.parse('$baseUrl/api/search?q=${Uri.encodeComponent(query)}&limit=40'),
        headers: headers,
      );
      if (res.statusCode == 200) return jsonDecode(res.body);
    } catch (_) {}
    return {};
  }

  Future<List> getChat(String id) async {
    try {
      final res = await http.get(Uri.parse('$baseUrl/api/streams/$id/chat?limit=60'), headers: headers);
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        return data is List ? data : (data['data'] ?? []);
      }
    } catch (_) {}
    return [];
  }

  Future<bool> sendChat(String id, String message) async {
    try {
      final res = await http.post(
        Uri.parse('$baseUrl/api/streams/$id/chat'),
        headers: headers,
        body: jsonEncode({'message': message}),
      );
      return res.statusCode == 200 || res.statusCode == 201;
    } catch (_) {}
    return false;
  }
}
