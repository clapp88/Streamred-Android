# StreamRed Android v1.6

## New
- **Chat auto-refresh every 2 seconds**
  - Only the chat is refreshed
  - Video stream continues playing uninterrupted
  - Messages from the website appear automatically

## Build
```bash
flutter pub get
flutter build apk --release
```
