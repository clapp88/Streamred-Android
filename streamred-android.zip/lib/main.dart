import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'screens/home_screen.dart';
import 'services/api_service.dart';

void main() {
  runApp(const StreamRedApp());
}

class StreamRedApp extends StatelessWidget {
  const StreamRedApp({super.key});

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      create: (_) => ApiService(),
      child: MaterialApp(
        title: 'StreamRed',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(
          brightness: Brightness.dark,
          primarySwatch: Colors.purple,
          scaffoldBackgroundColor: const Color(0xFF0E0E10),
          appBarTheme: const AppBarTheme(
            backgroundColor: Color(0xFF18181B),
            elevation: 0,
          ),
          bottomNavigationBarTheme: const BottomNavigationBarThemeData(
            backgroundColor: Color(0xFF18181B),
            selectedItemColor: Colors.purple,
            unselectedItemColor: Colors.grey,
          ),
        ),
        home: const HomeScreen(),
      ),
    );
  }
}
