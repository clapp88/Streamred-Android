import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/api_service.dart';
import 'stream_screen.dart';

class SearchScreen extends StatefulWidget {
  const SearchScreen({super.key});

  @override
  State<SearchScreen> createState() => _SearchScreenState();
}

class _SearchScreenState extends State<SearchScreen> {
  final _controller = TextEditingController();
  Map<String, dynamic> results = {};
  bool searching = false;

  Future<void> _search() async {
    if (_controller.text.trim().isEmpty) return;
    setState(() => searching = true);
    final api = context.read<ApiService>();
    final data = await api.search(_controller.text.trim());
    setState(() {
      results = data;
      searching = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    final streams = results['streams'] as List? ?? [];
    final channels = results['channels'] as List? ?? [];

    return Scaffold(
      appBar: AppBar(title: const Text('Search')),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: TextField(
              controller: _controller,
              decoration: InputDecoration(
                hintText: 'Search streams, channels...',
                suffixIcon: IconButton(icon: const Icon(Icons.search), onPressed: _search),
                border: const OutlineInputBorder(),
              ),
              onSubmitted: (_) => _search(),
            ),
          ),
          if (searching) const LinearProgressIndicator(),
          Expanded(
            child: ListView(
              children: [
                if (streams.isNotEmpty) const ListTile(title: Text('Streams', style: TextStyle(fontWeight: FontWeight.bold))),
                ...streams.map((s) => ListTile(
                      title: Text(s['title'] ?? ''),
                      subtitle: Text(s['channelName'] ?? ''),
                      onTap: () => Navigator.push(
                        context,
                        MaterialPageRoute(builder: (_) => StreamScreen(nanoId: s['nanoId'])),
                      ),
                    )),
                if (channels.isNotEmpty) const ListTile(title: Text('Channels', style: TextStyle(fontWeight: FontWeight.bold))),
                ...channels.map((c) => ListTile(
                      title: Text(c['name'] ?? c['username'] ?? ''),
                      subtitle: Text('${c['followerCount'] ?? 0} followers'),
                    )),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
