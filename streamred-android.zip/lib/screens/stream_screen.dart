import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:video_player/video_player.dart';
import 'package:chewie/chewie.dart';
import '../services/api_service.dart';

class StreamScreen extends StatefulWidget {
  final String nanoId;
  const StreamScreen({super.key, required this.nanoId});

  @override
  State<StreamScreen> createState() => _StreamScreenState();
}

class _StreamScreenState extends State<StreamScreen> {
  Map<String, dynamic>? stream;
  VideoPlayerController? _videoController;
  ChewieController? _chewieController;
  List<dynamic> chat = [];
  final _chatController = TextEditingController();
  bool loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final api = context.read<ApiService>();
    final data = await api.getStream(widget.nanoId);
    final messages = await api.getChat(widget.nanoId);
    setState(() {
      stream = data;
      chat = messages;
      loading = false;
    });

    if (data?['hlsUrl'] != null && data!['hlsUrl'].toString().isNotEmpty) {
      _initPlayer(data['hlsUrl']);
    }
  }

  void _initPlayer(String url) {
    _videoController = VideoPlayerController.networkUrl(Uri.parse(url));
    _chewieController = ChewieController(
      videoPlayerController: _videoController!,
      autoPlay: true,
      looping: false,
      aspectRatio: 16 / 9,
    );
    setState(() {});
  }

  Future<void> _sendChat() async {
    if (_chatController.text.trim().isEmpty) return;
    final api = context.read<ApiService>();
    final success = await api.sendChat(widget.nanoId, _chatController.text.trim());
    if (success) {
      _chatController.clear();
      final messages = await api.getChat(widget.nanoId);
      setState(() => chat = messages);
    }
  }

  @override
  void dispose() {
    _videoController?.dispose();
    _chewieController?.dispose();
    _chatController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(stream?['title'] ?? 'Stream')),
      body: loading
          ? const Center(child: CircularProgressIndicator())
          : Column(
              children: [
                if (_chewieController != null)
                  AspectRatio(
                    aspectRatio: 16 / 9,
                    child: Chewie(controller: _chewieController!),
                  )
                else
                  Container(
                    height: 200,
                    color: Colors.black,
                    child: const Center(child: Text('Stream offline or no HLS URL')),
                  ),
                Expanded(
                  child: ListView.builder(
                    itemCount: chat.length,
                    itemBuilder: (context, i) {
                      final m = chat[i];
                      return ListTile(
                        dense: true,
                        title: Text(m['username'] ?? m['user']?['username'] ?? 'User'),
                        subtitle: Text(m['message'] ?? m['content'] ?? ''),
                      );
                    },
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Row(
                    children: [
                      Expanded(
                        child: TextField(
                          controller: _chatController,
                          decoration: const InputDecoration(
                            hintText: 'Send a message...',
                            border: OutlineInputBorder(),
                          ),
                        ),
                      ),
                      IconButton(
                        icon: const Icon(Icons.send),
                        onPressed: _sendChat,
                      ),
                    ],
                  ),
                ),
              ],
            ),
    );
  }
}
