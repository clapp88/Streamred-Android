import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/api_service.dart';
import 'stream_screen.dart';
import 'search_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  List<dynamic> streams = [];
  bool loading = true;

  @override
  void initState() {
    super.initState();
    _loadStreams();
  }

  Future<void> _loadStreams() async {
    final api = context.read<ApiService>();
    final data = await api.getStreams();
    setState(() {
      streams = data;
      loading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('StreamRed'),
        actions: [
          IconButton(
            icon: const Icon(Icons.search),
            onPressed: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const SearchScreen()),
            ),
          ),
        ],
      ),
      body: loading
          ? const Center(child: CircularProgressIndicator())
          : RefreshIndicator(
              onRefresh: _loadStreams,
              child: streams.isEmpty
                  ? const Center(child: Text('No live streams right now'))
                  : ListView.builder(
                      itemCount: streams.length,
                      itemBuilder: (context, index) {
                        final s = streams[index];
                        return ListTile(
                          leading: CircleAvatar(
                            backgroundImage: s['avatar'] != null
                                ? NetworkImage('https://88streams.st${s['avatar']}')
                                : null,
                          ),
                          title: Text(s['title'] ?? 'Untitled'),
                          subtitle: Text('${s['channelName'] ?? ''} • ${s['viewers'] ?? 0} viewers'),
                          trailing: s['isLive'] == true
                              ? const Chip(label: Text('LIVE', style: TextStyle(color: Colors.white)), backgroundColor: Colors.red)
                              : null,
                          onTap: () => Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (_) => StreamScreen(nanoId: s['nanoId']),
                            ),
                          ),
                        );
                      },
                    ),
            ),
    );
  }
}
