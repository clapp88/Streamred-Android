import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

class ApiService extends ChangeNotifier {
  static const String baseUrl = 'https://88streams.st';
  String? _token;

  Future<void> loadToken() async {
    final prefs = await SharedPreferences.getInstance();
    _token = prefs.getString('auth_token');
    notifyListeners();
  }

  Future<void> saveToken(String token) async {
    _token = token;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('auth_token', token);
    notifyListeners();
  }

  Map<String, String> get headers => {
        'Content-Type': 'application/json',
        if (_token != null) 'Authorization': 'Bearer $_token',
      };

  Future<List<dynamic>> getStreams({int limit = 20, int offset = 0}) async {
    final response = await http.get(
      Uri.parse('$baseUrl/api/streams?limit=$limit&offset=$offset'),
      headers: headers,
    );
    if (response.statusCode == 200) {
      final data = jsonDecode(response.body);
      return data['data'] ?? [];
    }
    return [];
  }

  Future<Map<String, dynamic>?> getStream(String nanoId) async {
    final response = await http.get(
      Uri.parse('$baseUrl/api/streams/$nanoId'),
      headers: headers,
    );
    if (response.statusCode == 200) {
      return jsonDecode(response.body);
    }
    return null;
  }

  Future<Map<String, dynamic>> search(String query) async {
    final response = await http.get(
      Uri.parse('$baseUrl/api/search?q=${Uri.encodeComponent(query)}&limit=20'),
      headers: headers,
    );
    if (response.statusCode == 200) {
      return jsonDecode(response.body);
    }
    return {};
  }

  Future<List<dynamic>> getChat(String streamId, {int limit = 50}) async {
    final response = await http.get(
      Uri.parse('$baseUrl/api/streams/$streamId/chat?limit=$limit'),
      headers: headers,
    );
    if (response.statusCode == 200) {
      final data = jsonDecode(response.body);
      return data is List ? data : (data['data'] ?? []);
    }
    return [];
  }

  Future<bool> sendChat(String streamId, String message) async {
    final response = await http.post(
      Uri.parse('$baseUrl/api/streams/$streamId/chat'),
      headers: headers,
      body: jsonEncode({'message': message}),
    );
    return response.statusCode == 200 || response.statusCode == 201;
  }

  Future<bool> login(String username, String password) async {
    final response = await http.post(
      Uri.parse('$baseUrl/api/auth/login'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({'username': username, 'password': password}),
    );
    if (response.statusCode == 200) {
      final data = jsonDecode(response.body);
      if (data['token'] != null) {
        await saveToken(data['token']);
        return true;
      }
    }
    return false;
  }
}
