# StreamRed Android

Mobile Android app for the StreamRed / 88Streams platform.

Built with Flutter for a native, mobile-first experience similar to Twitch or YouTube.

## Features
- Browse live and recent streams
- Search streams and channels
- Watch streams via HLS (`hlsUrl`)
- Live chat (read + send)
- Authentication ready (login)

## Build APK

```bash
flutter pub get
flutter build apk --release
```

The APK will be at `build/app/outputs/flutter-apk/app-release.apk`.

## Requirements
- Flutter SDK
- Android Studio / Android SDK

## API
Uses the public StreamRed API at `https://88streams.st`.

---
Generated for mobile streaming use.
